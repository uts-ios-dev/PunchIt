Punch It App Icon
Nicholas Santoso

Version 1 : Without card
Version 2 : With card

Each version has 2 types, with white background (you can ask me to change into another colour), or with transparent background

All versions, all types are already prepared to be AppIcon in Xcode with their specific size

20 = 20x20 pixel
120 = 120x120 pixel